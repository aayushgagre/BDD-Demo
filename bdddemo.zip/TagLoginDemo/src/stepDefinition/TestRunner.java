package stepDefinition;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;

import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(features= {"src/taglogin"},glue= {"stepDefinition"},tags={"@tag_login_email"})
public class TestRunner {
	

}
